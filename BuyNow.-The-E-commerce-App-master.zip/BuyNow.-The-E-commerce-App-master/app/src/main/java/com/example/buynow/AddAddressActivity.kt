package com.example.buynow

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AddAddressActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_address)
    }
}