package com.example.buynow

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ShipingAddressActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shiping_address)
    }
}