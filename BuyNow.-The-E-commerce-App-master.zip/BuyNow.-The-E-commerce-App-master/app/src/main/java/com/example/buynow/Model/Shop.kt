package com.example.buynow.Model

data class Shop(
    val shopName: String = "",
    val shopImage: String = "",
    val shopAddress: String = ""
) {
}