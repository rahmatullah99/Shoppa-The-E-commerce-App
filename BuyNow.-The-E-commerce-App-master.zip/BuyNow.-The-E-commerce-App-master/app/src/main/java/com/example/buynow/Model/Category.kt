package com.example.buynow.Model

data class Category(
    val Name: String,
    val Image: String
) {
}