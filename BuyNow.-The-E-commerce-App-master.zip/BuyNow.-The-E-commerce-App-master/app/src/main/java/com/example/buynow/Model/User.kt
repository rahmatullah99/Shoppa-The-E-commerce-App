package com.example.buynow.Model

data class User(
    val userName: String = "",
    val userImage:String = "",
    val userUid:String = "",
    val userEmail:String = "",
    val userAddress:String = "",
    val userPhone: String = ""
)